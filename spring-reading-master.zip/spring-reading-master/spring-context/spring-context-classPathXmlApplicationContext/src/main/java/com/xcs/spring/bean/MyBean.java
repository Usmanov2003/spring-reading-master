package com.xcs.spring.bean;

/**
 * @author xcs
 * @date 2023年11月23日 16时28分
 **/
public class MyBean {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
