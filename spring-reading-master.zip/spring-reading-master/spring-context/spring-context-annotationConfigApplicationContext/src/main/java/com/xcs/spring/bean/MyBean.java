package com.xcs.spring.bean;

/**
 * @author xcs
 * @date 2023年11月22日 11时23分
 **/
public class MyBean {
}
