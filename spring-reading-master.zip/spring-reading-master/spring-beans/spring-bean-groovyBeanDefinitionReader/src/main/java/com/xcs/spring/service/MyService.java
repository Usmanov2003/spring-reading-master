package com.xcs.spring.service;

public interface MyService {
    void showMessage();
}
