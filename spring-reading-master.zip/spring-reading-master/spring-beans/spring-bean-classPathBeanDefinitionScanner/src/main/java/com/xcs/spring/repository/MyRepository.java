package com.xcs.spring.repository;

import org.springframework.stereotype.Repository;

/**
 * @author xcs
 * @date 2023年11月07日 17时46分
 **/
@Repository
public class MyRepository {
}
