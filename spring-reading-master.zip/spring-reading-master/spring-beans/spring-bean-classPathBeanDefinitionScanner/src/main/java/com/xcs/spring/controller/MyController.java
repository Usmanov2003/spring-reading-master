package com.xcs.spring.controller;

import org.springframework.stereotype.Controller;

/**
 * @author xcs
 * @date 2023年11月07日 17时47分
 **/
@Controller
public class MyController {
}
