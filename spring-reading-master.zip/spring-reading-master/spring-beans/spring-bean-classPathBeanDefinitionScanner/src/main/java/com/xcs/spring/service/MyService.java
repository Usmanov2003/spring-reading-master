package com.xcs.spring.service;

import org.springframework.stereotype.Service;

/**
 * @author xcs
 * @date 2023年11月07日 17时46分
 **/
@Service
public class MyService {
}
