package com.xcs.spring.bean;

/**
 * @author xcs
 * @date 2023年11月07日 16时15分
 **/
public class MyBean {
}
