package com.xcs.spring.service;

import org.springframework.stereotype.Service;

/**
 * @author xcs
 * @date 2023年10月25日 10时36分
 **/
@Service
public class MyServiceA {

}
