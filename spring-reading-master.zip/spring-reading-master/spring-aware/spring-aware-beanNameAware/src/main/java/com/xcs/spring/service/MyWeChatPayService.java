package com.xcs.spring.service;

import org.springframework.stereotype.Service;

@Service
public class MyWeChatPayService extends MyBasePayService{
}
