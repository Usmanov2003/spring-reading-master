package com.xcs.spring.service;

public class UserServiceImpl implements UserService {
    @Override
    public String getUserInfo() {
        return "this is user info";
    }
}
