package com.xcs.spring.service;

public interface UserService {

    String getUserInfo();
}
