package com.xcs.spring.bean;

/**
 * @author xcs
 * @date 2023年09月11日 11时13分
 **/
public class MyBean {

}
