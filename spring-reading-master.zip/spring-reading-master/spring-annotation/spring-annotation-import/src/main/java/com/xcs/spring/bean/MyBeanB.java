package com.xcs.spring.bean;

/**
 * @author xcs
 * @date 2023年08月28日 11时13分
 **/
public class MyBeanB {
}
