package com.xcs.spring.bean;

public class MyBean {

    public MyBean() {
        System.out.println("MyBean 的构造函数被调用了!");
    }

    public void show() {
        System.out.println("hello world!");
    }
}
