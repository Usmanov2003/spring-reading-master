package com.xcs.spring.repository;

import org.springframework.stereotype.Repository;

/**
 * @author xcs
 * @date 2023年10月07日 11时51分
 **/
@Repository
public class UserRepository {

}
