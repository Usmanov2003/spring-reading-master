package com.xcs.spring.service;

import org.springframework.stereotype.Service;

/**
 * @author xcs
 * @date 2023年10月07日 11时51分
 **/
@Service
public class AdminService {

}
