package com.xcs.spring.special;

/**
 * @author xcs
 * @date 2023年10月07日 11时52分
 **/
public class SpecialComponent {
}
