package com.xcs.spring.bean;

/**
 * @author xcs
 * @date 2023年08月07日 16时26分
 **/
public class MyBean {

}
