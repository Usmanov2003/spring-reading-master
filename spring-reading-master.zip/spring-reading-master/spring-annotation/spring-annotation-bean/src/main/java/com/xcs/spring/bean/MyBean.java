package com.xcs.spring.bean;

/**
 * @author xcs
 * @date 2023年08月25日 10时22分
 **/
public class MyBean {

    public void init(){
        System.out.println("MyBean.init");
    }

    public void destroy(){
        System.out.println("MyBean.destroy");
    }
}
