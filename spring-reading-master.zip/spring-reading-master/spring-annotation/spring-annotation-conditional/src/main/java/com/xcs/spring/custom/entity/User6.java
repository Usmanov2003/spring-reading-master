package com.xcs.spring.custom.entity;

public class User6 {
}
