package com.xcs.spring.bean.entity;

public class User2 {

}
