package com.xcs.spring.configuration.entity;

public class User3 {
}
