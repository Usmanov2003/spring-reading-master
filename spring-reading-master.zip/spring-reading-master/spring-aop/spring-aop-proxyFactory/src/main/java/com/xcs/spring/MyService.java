package com.xcs.spring;

public class MyService {

}
