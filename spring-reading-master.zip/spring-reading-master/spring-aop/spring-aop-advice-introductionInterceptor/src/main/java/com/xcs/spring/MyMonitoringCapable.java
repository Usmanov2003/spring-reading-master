package com.xcs.spring;

public interface MyMonitoringCapable {
    void toggleMonitoring();
}
