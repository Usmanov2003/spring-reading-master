package com.xcs.spring;

public class MyServiceImpl implements MyService {

    @Override
    public void doSomething() {
        System.out.println("hello world");
    }
}
