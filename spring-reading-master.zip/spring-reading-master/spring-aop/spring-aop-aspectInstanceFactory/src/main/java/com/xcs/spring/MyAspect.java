package com.xcs.spring;

import org.aspectj.lang.annotation.Aspect;

@Aspect
class MyAspect {

}
