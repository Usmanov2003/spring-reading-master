package com.xcs.spring;

public class MyService {

    public void foo() {
        System.out.println("foo...");
    }
}
