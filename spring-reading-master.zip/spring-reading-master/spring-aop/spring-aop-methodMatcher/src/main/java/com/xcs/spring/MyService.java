package com.xcs.spring;

public class MyService {

    @MyMethodAnnotation
    public void setName() {
        System.out.println("setName...");
    }
}
