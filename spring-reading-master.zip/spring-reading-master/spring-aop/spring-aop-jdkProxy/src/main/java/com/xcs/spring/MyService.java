package com.xcs.spring;

public interface MyService {

    void doSomething();

}
