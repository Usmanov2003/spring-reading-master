package com.xcs.spring;

public interface MyService {
    void foo();
}
