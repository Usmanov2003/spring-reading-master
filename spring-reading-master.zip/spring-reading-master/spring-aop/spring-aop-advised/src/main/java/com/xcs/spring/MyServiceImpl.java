package com.xcs.spring;

public class MyServiceImpl implements MyService {

    @Override
    public void foo() {
        System.out.println("foo...");
    }
}
