package com.xcs.spring;

public class MySubService extends MyService{
}
