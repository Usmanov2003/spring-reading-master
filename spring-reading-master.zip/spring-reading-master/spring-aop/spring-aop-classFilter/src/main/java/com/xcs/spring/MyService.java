package com.xcs.spring;

@MyClassAnnotation
public class MyService {
}
