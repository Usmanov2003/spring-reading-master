package com.xcs.spring;

public class MyServiceImpl implements MyService {

    @Override
    public String doSomething() {
        return "hello world";
    }
}
