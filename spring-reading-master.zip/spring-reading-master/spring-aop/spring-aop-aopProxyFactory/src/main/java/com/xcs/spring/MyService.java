package com.xcs.spring;

public interface MyService {

    String doSomething();

}
