package com.xcs.spring.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author xcs
 * @date 2023年11月24日 14时17分
 **/
@Configuration
public class MyConfiguration {

}
