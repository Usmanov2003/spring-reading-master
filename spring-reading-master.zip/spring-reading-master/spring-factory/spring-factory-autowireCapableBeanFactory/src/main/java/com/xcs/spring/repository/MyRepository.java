package com.xcs.spring.repository;

/**
 * @author xcs
 * @date 2023年11月27日 11时36分
 **/
public class MyRepository {
}
