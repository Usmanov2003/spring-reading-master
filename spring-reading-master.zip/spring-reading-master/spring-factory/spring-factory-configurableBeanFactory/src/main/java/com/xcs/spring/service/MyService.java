package com.xcs.spring.service;

/**
 * @author xcs
 * @date 2023年11月24日 14时17分
 **/
public interface MyService {

    void greet();
}
